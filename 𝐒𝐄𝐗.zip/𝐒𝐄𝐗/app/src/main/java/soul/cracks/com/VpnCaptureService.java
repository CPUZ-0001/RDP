package soul.cracks.com;

import android.net.VpnService;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;

public class VpnCaptureService extends VpnService {

    private static final String TAG = "VpnCaptureService";
    private ParcelFileDescriptor vpnInterface;

    @Override
    public void onCreate() {
        super.onCreate();

        Builder builder = new Builder();
        builder.setSession("VpnTrafficCapture")
               .addAddress("10.0.0.2", 24)
               .addDnsServer("8.8.8.8")
               .addRoute("0.0.0.0", 0);

        vpnInterface = builder.establish();

        new Thread(() -> {
            try (FileInputStream in = new FileInputStream(vpnInterface.getFileDescriptor())) {
                ByteBuffer packet = ByteBuffer.allocate(32767);
                while (true) {
                    int length = in.read(packet.array());
                    if (length > 0) {
                        packet.limit(length);
                        analyzePacket(packet);
                        packet.clear();
                    }
                }
            } catch (IOException e) {
                Log.e(TAG, "Error reading VPN interface", e);
            }
        }).start();
    }

    private void analyzePacket(ByteBuffer packet) {
        try {

            byte version = packet.get(0);
            if ((version >> 4) == 4) {
                int headerLength = (packet.get(0) & 0x0F) * 4;
                int protocol = packet.get(9) & 0xFF;

                if (protocol == 17) {
                    String srcIP = (packet.get(12) & 0xFF) + "." + (packet.get(13) & 0xFF) + "." +
                                   (packet.get(14) & 0xFF) + "." + (packet.get(15) & 0xFF);
                    String dstIP = (packet.get(16) & 0xFF) + "." + (packet.get(17) & 0xFF) + "." +
                                   (packet.get(18) & 0xFF) + "." + (packet.get(19) & 0xFF);

                    int srcPort = ((packet.get(headerLength) & 0xFF) << 8) | (packet.get(headerLength + 1) & 0xFF);
                    int dstPort = ((packet.get(headerLength + 2) & 0xFF) << 8) | (packet.get(headerLength + 3) & 0xFF);


                    Log.d(TAG, "UDP Packet - Source IP: " + srcIP + ", Source Port: " + srcPort + 
                          ", Destination IP: " + dstIP + ", Destination Port: " + dstPort);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error analyzing packet", e);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        try {
            vpnInterface.close();
        } catch (IOException e) {
            Log.e(TAG, "Error closing VPN interface", e);
        }
    }
}
